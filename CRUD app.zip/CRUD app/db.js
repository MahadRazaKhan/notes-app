require('dotenv').config();
const mysql = require('mysql2/promise');
const { exit } = require('process');

const requiredVars = ['DB_HOST', 'DB_USER', 'DB_PASSWORD', 'DB_NAME'];
const missingVars = requiredVars.filter(v => typeof process.env[v] === 'undefined');

if (missingVars.length > 0) {
  console.error(`Error: Missing required environment variables: ${missingVars.join(', ')}`);
  if (process.env.NODE_ENV === 'production') {
    exit(1);
  } else {
    console.warn('⚠️ Continuing in development mode (some vars undefined)');
  }
}

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'root',
  database: process.env.DB_NAME || 'notes_app',
  waitForConnections: true,
  connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT, 10) || 10,
  queueLimit: parseInt(process.env.DB_QUEUE_LIMIT, 10) || 0,
  decimalNumbers: true,
  timezone: '+00:00',
  charset: 'utf8mb4',
  multipleStatements: false,
  connectTimeout: 10000,
  acquireTimeout: 10000,
  namedPlaceholders: false,
});

async function checkDatabaseConnection() {
  let connection;
  try {
    connection = await pool.getConnection();
    await connection.ping();
    const [rows] = await connection.query('SELECT 1 + 1 AS result');
    if (!rows || !rows[0] || rows[0].result !== 2) {
      throw new Error('Test query failed');
    }
    console.log('MySQL connection pool established.');
    return true;
  } catch (err) {
    console.error('Database connection failed:', err.message);
    return false;
  } finally {
    if (connection) connection.release();
  }
}

(async () => {
  const ok = await checkDatabaseConnection();
  if (!ok && process.env.NODE_ENV === 'production') {
    exit(1);
  }
})();

process.on('SIGINT', async () => {
  console.log('\n SIGINT received. Closing MySQL pool...');
  try {
    await pool.end();
    console.log('MySQL pool closed.');
    exit(0);
  } catch (err) {
    console.error('Error closing pool:', err);
    exit(1);
  }
});

pool.checkDatabaseConnection = checkDatabaseConnection;

module.exports = pool;
