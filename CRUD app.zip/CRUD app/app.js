require('dotenv').config();
const express = require('express');
const pool = require('./db');
const cors = require('cors');
const { body, param, validationResult } = require('express-validator');

const app = express();

process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

app.use(cors());
app.use(express.json());

function handleValidationErrors(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
}

app.get('/notes', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM notes ORDER BY updated_at DESC');
    res.json(rows);
  } catch (err) {
    console.error('Error fetching notes:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get(
  '/notes/:id',
  param('id').isInt({ gt: 0 }).withMessage('ID must be a positive integer'),
  handleValidationErrors,
  async (req, res) => {
    try {
      const noteId = parseInt(req.params.id, 10);
      const [rows] = await pool.query('SELECT * FROM notes WHERE id = ?', [noteId]);
      if (rows.length === 0) {
        return res.status(404).json({ error: 'Note not found' });
      }
      res.json(rows[0]);
    } catch (err) {
      console.error('Error fetching note:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
);

app.post(
  '/notes',
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('content').optional().isString(),
  handleValidationErrors,
  async (req, res) => {
    try {
      const { title, content } = req.body;
      const [result] = await pool.query(
        'INSERT INTO notes (title, content) VALUES (?, ?)',
        [title, content || null]
      );
      const insertedId = result.insertId;
      const [rows] = await pool.query('SELECT * FROM notes WHERE id = ?', [insertedId]);
      res.status(201).json(rows[0]);
    } catch (err) {
      console.error('Error creating note:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
);

app.put(
  '/notes/:id',
  param('id').isInt({ gt: 0 }).withMessage('ID must be a positive integer'),
  body('title').optional().trim().notEmpty().withMessage('Title, if provided, cannot be empty'),
  body('content').optional().isString(),
  handleValidationErrors,
  async (req, res) => {
    try {
      const noteId = parseInt(req.params.id, 10);
      const { title, content } = req.body;
      const [existing] = await pool.query('SELECT * FROM notes WHERE id = ?', [noteId]);
      if (existing.length === 0) {
        return res.status(404).json({ error: 'Note not found' });
      }
      const fields = [];
      const values = [];
      if (title !== undefined) {
        fields.push('title = ?');
        values.push(title);
      }
      if (content !== undefined) {
        fields.push('content = ?');
        values.push(content);
      }
      if (fields.length === 0) {
        return res.status(400).json({ error: 'Nothing to update' });
      }
      values.push(noteId);
      const sql = `UPDATE notes SET ${fields.join(', ')} WHERE id = ?`;
      await pool.query(sql, values);
      const [updatedRows] = await pool.query('SELECT * FROM notes WHERE id = ?', [noteId]);
      res.json(updatedRows[0]);
    } catch (err) {
      console.error('Error updating note:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
);

app.delete(
  '/notes/:id',
  param('id').isInt({ gt: 0 }).withMessage('ID must be a positive integer'),
  handleValidationErrors,
  async (req, res) => {
    try {
      const noteId = parseInt(req.params.id, 10);
      const [result] = await pool.query('DELETE FROM notes WHERE id = ?', [noteId]);
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Note not found' });
      }
      res.status(204).send();
    } catch (err) {
      console.error('Error deleting note:', err);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
);

app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.status(200).json({ status: 'healthy' });
  } catch (err) {
    console.error('Database connection failed:', err);
    res.status(500).json({ status: 'unhealthy', error: 'Database connection failed' });
  }
});

app.get('/', (req, res) => res.send('Notes API is running'));

app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

const port = parseInt(process.env.PORT, 10) || 3000;
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});

module.exports = app;
